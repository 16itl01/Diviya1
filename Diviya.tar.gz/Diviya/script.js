function calculateSupply(){
  var myAge=document.getElementById('myAge').value;
  var maxAge=100;
  var cupsAmount= document.getElementById('myTea').value; 
  var totalSupply=(cupsAmount * 365) * (maxAge - myAge);  
  alert("You will need "+(totalSupply)+ " packs of lays to last you until the ripe old age of 100.");
}

function calcCircumfrence() {
   var diameter = prompt("please enter a number") ;
  var cir = Math.PI*diameter 
  document.getElementById("CircumferenceOutput").innerHTML = "The circumference is "+ cir + "." 
}

function Age()
{
var bday=parseInt(document.forms[0].txtBday.value);
var bmo=(parseInt(document.forms[0].txtBmo.value)-1);
var byr=parseInt(document.forms[0].txtByr.value);
var byr;
var age;
var now = new Date();
tday=now.getDate();
tmo=(now.getMonth());
tyr=(now.getFullYear());
{
if((tmo > bmo)||(tmo==bmo & tday>=bday))
{age=byr}
else
{age=byr+1}
alert("you are:"+(tyr-age)+ " years old");
}}


